package io.aniruddh.deepblue.tensorflow;

public class Constants {
    public static final String SERVER_API = "http://192.168.0.106:5000/mobile/";
    public static final String CDN_IMAGES = "http://192.168.0.106:5000/downloads/";

}
